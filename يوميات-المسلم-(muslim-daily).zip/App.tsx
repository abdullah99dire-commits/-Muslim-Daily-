import React, { useState, useEffect, useCallback } from 'react';
import { INITIAL_TASKS, STORAGE_KEY } from './constants';
import { Task, AppState } from './types';
import { TaskItem } from './components/TaskItem';
import { ProgressBar } from './components/ProgressBar';
import { AdhkarModal } from './components/AdhkarModal';
import { Moon, Sun } from 'lucide-react';

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  
  // State for the modal
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const getTodayDateString = () => {
    return new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD format regardless of locale
  };

  // Load and Reset Logic
  useEffect(() => {
    const storedData = localStorage.getItem(STORAGE_KEY);
    const today = getTodayDateString();

    if (storedData) {
      try {
        const parsedData: AppState = JSON.parse(storedData);
        
        // Restore Dark Mode
        if (parsedData.isDarkMode) {
          setIsDarkMode(parsedData.isDarkMode);
        }

        // Check if date changed
        if (parsedData.lastVisitDate !== today) {
          // Reset tasks for new day but keep dark mode preference
          // We need to merge INITIAL_TASKS content with the structure
          setTasks(INITIAL_TASKS);
          saveToStorage(INITIAL_TASKS, today, parsedData.isDarkMode);
        } else {
          // Restore saved state, but merge with INITIAL_TASKS to ensure new content (Adhkar text) appears
          // even for existing users who have old data stored
          const mergedTasks = INITIAL_TASKS.map(initTask => {
            const savedTask = parsedData.tasks.find(t => t.id === initTask.id);
            return savedTask ? { ...initTask, completed: savedTask.completed } : initTask;
          });
          setTasks(mergedTasks);
        }
      } catch (e) {
        console.error("Failed to parse storage", e);
        setTasks(INITIAL_TASKS);
        saveToStorage(INITIAL_TASKS, today, false);
      }
    } else {
      // First time visit
      saveToStorage(INITIAL_TASKS, today, false);
    }
    setIsLoaded(true);
  }, []);

  const saveToStorage = (currentTasks: Task[], date: string, darkMode: boolean = isDarkMode) => {
    const newState: AppState = {
      tasks: currentTasks,
      lastVisitDate: date,
      isDarkMode: darkMode
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
  };

  const handleToggle = useCallback((id: string) => {
    setTasks(prevTasks => {
      const newTasks = prevTasks.map(task => 
        task.id === id ? { ...task, completed: !task.completed } : task
      );
      saveToStorage(newTasks, getTodayDateString(), isDarkMode);
      return newTasks;
    });
    
    // Haptic feedback if available
    if (window.navigator && window.navigator.vibrate) {
      window.navigator.vibrate(50);
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    saveToStorage(tasks, getTodayDateString(), newMode);
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <div className={isDarkMode ? 'dark' : ''}>
      <div className="min-h-screen pb-10 bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        {/* Header Section */}
        <header className="bg-white dark:bg-gray-800 pt-12 pb-8 px-6 rounded-b-[2.5rem] shadow-sm mb-6 relative overflow-hidden transition-colors duration-300">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-400 to-teal-500"></div>
          
          <div className="relative z-10 flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">السلام عليكم</h1>
              <p className="text-gray-500 dark:text-gray-400">
                {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
            
            <button 
              onClick={toggleDarkMode}
              className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-yellow-400 transition-colors hover:bg-gray-200 dark:hover:bg-gray-600"
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
            </button>
          </div>

          {/* Decorative circle */}
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-emerald-50 dark:bg-emerald-900/20 rounded-full blur-3xl opacity-60"></div>
        </header>

        {/* Main Content */}
        <main className="max-w-md mx-auto px-4">
          
          <ProgressBar total={tasks.length} completed={completedCount} />

          <div className="space-y-4">
            {tasks.map((task) => (
              <TaskItem 
                key={task.id} 
                task={task} 
                onToggle={handleToggle}
                onOpenContent={setSelectedTask} 
              />
            ))}
          </div>

          {completedCount === tasks.length && (
            <div className="mt-8 text-center animate-bounce">
              <span className="inline-block px-4 py-2 bg-yellow-100 text-yellow-800 rounded-full text-sm font-bold border border-yellow-200">
                🎉 ما شاء الله! أتممت مهام اليوم
              </span>
            </div>
          )}
        </main>
        
        <footer className="mt-12 text-center text-gray-400 dark:text-gray-600 text-sm pb-8">
          <p>لا تنسونا من صالح دعائكم</p>
        </footer>

        {/* Adhkar Modal */}
        <AdhkarModal 
          isOpen={!!selectedTask}
          title={selectedTask?.title || ''}
          adhkar={selectedTask?.content || []}
          onClose={() => setSelectedTask(null)}
        />
      </div>
    </div>
  );
};

export default App;