export enum TaskCategory {
  MORNING = 'MORNING',
  EVENING = 'EVENING',
  PRAYER = 'PRAYER',
  QURAN = 'QURAN',
  SLEEP = 'SLEEP',
}

export interface DhikrItem {
  text: string;
  count: number;
  note?: string;
}

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  completed: boolean;
  iconType: 'sun' | 'moon' | 'book' | 'prayer' | 'bed';
  link?: string;
  content?: DhikrItem[]; // List of Adhkar text
}

export interface AppState {
  tasks: Task[];
  lastVisitDate: string;
  isDarkMode?: boolean;
}