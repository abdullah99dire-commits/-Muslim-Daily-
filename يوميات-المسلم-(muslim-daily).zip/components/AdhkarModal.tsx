import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { DhikrItem } from '../types';

interface AdhkarModalProps {
  title: string;
  adhkar: DhikrItem[];
  isOpen: boolean;
  onClose: () => void;
}

export const AdhkarModal: React.FC<AdhkarModalProps> = ({ title, adhkar, isOpen, onClose }) => {
  // State to track counts for each dhikr item index
  const [counts, setCounts] = useState<number[]>([]);

  // Initialize counts when modal opens
  useEffect(() => {
    if (isOpen) {
      setCounts(new Array(adhkar.length).fill(0));
    }
  }, [isOpen, adhkar.length]);

  const handleTap = (index: number, targetCount: number) => {
    if (counts[index] < targetCount) {
      const newCounts = [...counts];
      newCounts[index] += 1;
      setCounts(newCounts);
      
      // Haptic feedback
      if (window.navigator && window.navigator.vibrate) {
        if (newCounts[index] >= targetCount) {
             // Success vibration (3 short pulses)
             window.navigator.vibrate([50, 50, 50]); 
        } else {
             // Tap vibration (short pulse)
             window.navigator.vibrate(15);
        }
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      ></div>

      {/* Modal Content */}
      <div className="relative bg-white dark:bg-gray-900 w-full max-w-lg rounded-t-[2rem] sm:rounded-3xl shadow-2xl flex flex-col max-h-[90vh] animate-in slide-in-from-bottom-10 fade-in duration-300">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-gray-800 shrink-0">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white">{title}</h2>
          <button 
            onClick={onClose}
            className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Scrollable List */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-4">
          {adhkar.map((item, index) => {
            const count = counts[index] || 0;
            const isCompleted = count >= item.count;
            
            return (
              <div 
                key={index}
                onClick={() => handleTap(index, item.count)}
                className={`
                  relative overflow-hidden rounded-2xl p-5 border transition-all duration-200 select-none cursor-pointer
                  active:scale-[0.98]
                  ${isCompleted 
                    ? 'bg-emerald-50 border-emerald-500 dark:bg-emerald-900/20 dark:border-emerald-500' 
                    : 'bg-gray-50 dark:bg-gray-800/50 border-gray-100 dark:border-gray-700 hover:border-emerald-200 dark:hover:border-emerald-800'
                  }
                `}
              >
                {/* Progress Bar (Background) */}
                <div 
                    className="absolute bottom-0 right-0 h-1.5 bg-emerald-500 transition-all duration-300 ease-out opacity-20"
                    style={{ width: `${(count / item.count) * 100}%` }}
                />

                <p className={`text-lg leading-loose font-medium mb-4 transition-colors ${
                    isCompleted ? 'text-emerald-900 dark:text-emerald-100' : 'text-gray-700 dark:text-gray-200'
                }`}>
                  {item.text}
                </p>
                
                <div className="flex items-center justify-between">
                    {/* Note or Spacer */}
                    <div>
                        {item.note && (
                        <span className="text-xs font-semibold text-gray-500 bg-gray-200 dark:bg-gray-700 dark:text-gray-300 px-3 py-1 rounded-full">
                            {item.note}
                        </span>
                        )}
                    </div>

                    {/* Counter UI */}
                    <div className="flex items-center gap-3">
                        <div className="text-left pl-1">
                             <span className={`text-sm font-bold block ${isCompleted ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400'}`}>
                                {isCompleted ? 'اكتمل' : `${count}/${item.count}`}
                             </span>
                        </div>

                        <div className={`
                            w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-sm
                            ${isCompleted 
                                ? 'bg-emerald-500 text-white scale-110 shadow-emerald-200 dark:shadow-none' 
                                : 'bg-white dark:bg-gray-700 text-primary border border-gray-200 dark:border-gray-600'
                            }
                        `}>
                            {isCompleted 
                                ? <Check className="w-6 h-6" /> 
                                : <span className="text-lg font-bold pt-1">{item.count - count}</span>
                            }
                        </div>
                    </div>
                </div>
              </div>
            );
          })}
          <div className="h-8"></div>
        </div>

        {/* Footer Action */}
        <div className="p-4 border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 rounded-b-[2rem] sm:rounded-b-3xl shrink-0">
          <button 
            onClick={onClose}
            className="w-full py-4 bg-primary text-white font-bold rounded-xl shadow-lg shadow-emerald-200 dark:shadow-none active:scale-[0.98] transition-transform"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};