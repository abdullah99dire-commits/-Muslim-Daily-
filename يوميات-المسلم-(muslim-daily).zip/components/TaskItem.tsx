import React from 'react';
import { Task } from '../types';
import { Sun, Moon, BookOpen, User, Bed, Check, ExternalLink, BookOpenText } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onOpenContent?: (task: Task) => void;
}

export const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onOpenContent }) => {
  
  const getIcon = (type: string) => {
    const className = `w-6 h-6 ${task.completed ? 'text-white' : 'text-primary'}`;
    switch (type) {
      case 'sun': return <Sun className={className} />;
      case 'moon': return <Moon className={className} />;
      case 'book': return <BookOpen className={className} />;
      case 'bed': return <Bed className={className} />;
      default: return <User className={className} />; // Prayer/Generic
    }
  };

  const handleLinkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (task.link) {
      window.open(task.link, '_blank');
    }
  };

  const handleOpenContent = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onOpenContent && task.content) {
      onOpenContent(task);
    }
  };

  return (
    <div 
      onClick={() => onToggle(task.id)}
      className={`
        relative overflow-hidden group cursor-pointer 
        transform transition-all duration-300 ease-out
        p-4 rounded-2xl border shadow-sm hover:shadow-md
        flex items-center gap-4 select-none
        ${task.completed 
          ? 'bg-primary border-primary translate-y-1' 
          : 'bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 hover:-translate-y-0.5'
        }
      `}
    >
      {/* Icon Container */}
      <div className={`
        flex items-center justify-center w-12 h-12 rounded-full transition-colors duration-300
        ${task.completed ? 'bg-white/20' : 'bg-emerald-50 dark:bg-emerald-900/30'}
      `}>
        {getIcon(task.iconType)}
      </div>

      {/* Text Content */}
      <div className="flex-1">
        <h3 className={`
          text-lg font-bold transition-colors duration-300
          ${task.completed 
            ? 'text-white decoration-2' 
            : 'text-gray-800 dark:text-gray-100'}
        `}>
          {task.title}
        </h3>
        <p className={`
          text-xs transition-colors duration-300
          ${task.completed 
            ? 'text-emerald-100' 
            : 'text-gray-400 dark:text-gray-400'}
        `}>
          {task.completed ? 'تم الإنجاز، تقبل الله' : 'اضغط للإتمام'}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2">
        {/* Read Button (Internal Content) */}
        {task.content && !task.completed && (
          <button
            onClick={handleOpenContent}
            className="p-2 rounded-full text-primary bg-emerald-50 hover:bg-emerald-100 dark:bg-gray-700 dark:text-emerald-400 dark:hover:bg-gray-600 transition-colors"
            title="قراءة الأذكار"
          >
            <BookOpenText className="w-5 h-5" />
          </button>
        )}

        {/* Link Button (External Link) - Fallback */}
        {task.link && !task.content && !task.completed && (
          <button
            onClick={handleLinkClick}
            className="p-2 rounded-full text-gray-400 hover:text-primary hover:bg-emerald-50 dark:hover:bg-gray-700 transition-colors"
            title="فتح الرابط"
          >
            <ExternalLink className="w-5 h-5" />
          </button>
        )}

        {/* Checkbox Visual */}
        <div className={`
          w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all duration-300
          ${task.completed 
            ? 'bg-white border-white scale-110' 
            : 'bg-transparent border-gray-300 dark:border-gray-600'
          }
        `}>
          {task.completed && <Check className="w-5 h-5 text-primary" />}
        </div>
      </div>
      
      {/* Decorative Background Pattern for completed state */}
      {task.completed && (
        <div className="absolute -left-4 -bottom-4 w-24 h-24 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
      )}
    </div>
  );
};